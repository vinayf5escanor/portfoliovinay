﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Assigment2
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        int gloop;
        public MainPage()
        {
            this.InitializeComponent();

            linas.Text = LoginUser.typeuser;

            if (LoginUser.typeuser != "admin")
            {
                ViewUsersbtn.Visibility = Visibility.Collapsed;
                updatebtn.Visibility= Visibility.Collapsed; 
                deletebtn.Visibility= Visibility.Collapsed; 
                addbtn.Visibility= Visibility.Collapsed;
            }



        }

        private void Movie1_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void TextBlock_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private async void eventbtn_Click(object sender, RoutedEventArgs e)
        {
            string cs = //"Server=LAPTOP-V3EC844G;Database= forprojects; User ID = darioPROG32356f; PASSWORD=12345";
            "Server = DESKTOP-E1KF7BF; Database = forprojects; USER ID = darioPROG32356f; PASSWORD = 12345";
            //step 1 create connections
            SqlConnection conn = new SqlConnection(cs);
            string query = "Select * from MOVIES";
            List<string> mov = new List<string>();
            //step 2 command object
            SqlCommand cmd = new SqlCommand(query, conn);

            //step 3
            conn.Open();

            //step 4: Execute the SQL Command by calling the 
            // sqlCommands's ExcuteReader()
            SqlDataReader reader = cmd.ExecuteReader();

            //the object returned (rader) can be used to 
            //iterate through the records returned
            
            while (reader.Read())
            {
                string firstname = (string)reader["NAME"];

                mov.Add(firstname);

            }
           

            //step 6
            conn.Close();


            int twin = 0;    
            var a = tb1.Text;
           // string[] mymovie = {"Avenger Endgame","The Conjuring","Avenger Infinity War","Joker","Justice League","Godzilla"};
            Random rd = new Random();
            string gameMasterGuess = mov[rd.Next(0, 6)];
            
            if(a==gameMasterGuess)
            {
                MessageDialog mg = new MessageDialog("The Game Master guess is " + gameMasterGuess + " and sir you Are CORRECT!!!!");
                await mg.ShowAsync();
                resultb.Text = "The Game Master guess is "+gameMasterGuess+" and you sir Are correct";
                twin = Convert.ToInt32(winlable.Text) + 1;
                winlable.Text = twin+"";
                gloop++;
                if (gloop >= 3)
                {
                    System.Environment.Exit(1);
                }

            }
            else 
            {
                MessageDialog mg = new MessageDialog("The Game Master guess is " + gameMasterGuess + " and sir you Are WRONG!!!");
                await mg.ShowAsync();
                resultb.Text = "The Game Master guess is " + gameMasterGuess + " and you sir Are WRONG";
                gloop++;
                if (gloop >= 3)
                {
                    System.Environment.Exit(1);
                }
            }

        }

        private void Movie2_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e) //LOGIN
        {
            this.Frame.Navigate(typeof(LoginUser));
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //ADD
        {
            this.Frame.Navigate(typeof(ADDUSER));

        }

        private void Button_Click_2(object sender, RoutedEventArgs e) //DELETE
        {
            this.Frame.Navigate(typeof(DELETEUSER));

        }

        private void Button_Click_3(object sender, RoutedEventArgs e) //UPDATE
        {
            this.Frame.Navigate(typeof(UPDATEUSER));
        }

        static async void printusers()
        {
            // using(string cs = GetConnectionString("NorthwindLocalDB")){} you don't have to close as it will automatically
            string cs = //"Server=LAPTOP-V3EC844G;Database= forprojects; User ID = darioPROG32356f; PASSWORD=12345";
            "Server = DESKTOP-E1KF7BF; Database = forprojects; USER ID = darioPROG32356f; PASSWORD = 12345";
            //step 1 create connections
            SqlConnection conn = new SqlConnection(cs);
            string query = "Select ID, NAME, PASS, " + "ROLES from USERS";

            //step 2 command object
            SqlCommand cmd = new SqlCommand(query, conn);

            //step 3
            conn.Open();

            //step 4: Execute the SQL Command by calling the 
            // sqlCommands's ExcuteReader()
            SqlDataReader reader = cmd.ExecuteReader();

            //the object returned (rader) can be used to 
            //iterate through the records returned
            string a = "";
            while (reader.Read())
            {
                int id = (int)reader["ID"];
                string firstname = (string)reader["NAME"];
                string lastNmae = (string)reader["PASS"];
                string lastNmEae = (string)reader["ROLES"];


                //step 5 display
                
                a=a+($"{id,-5}{firstname,-15}{lastNmae,-15}{lastNmEae,-15}\n");

            }
            MessageDialog mg = new MessageDialog(a);
            await mg.ShowAsync();

            //step 6
            conn.Close();

        }

        private void Button_Click_view(object sender, RoutedEventArgs e)
        {
            printusers();
        }

        private void Button_Click_logout(object sender, RoutedEventArgs e)
        {
            linas.Text = "GUEST";
                ViewUsersbtn.Visibility = Visibility.Collapsed;
                updatebtn.Visibility = Visibility.Collapsed;
                deletebtn.Visibility = Visibility.Collapsed;
                addbtn.Visibility = Visibility.Collapsed;
            
        }

    }
}
