﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Assigment2
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class UPDATEUSER : Page
    {
        public UPDATEUSER()
        {
            this.InitializeComponent();
        }

        private void home_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));

        }

        private async void UPuserbtn_Click(object sender, RoutedEventArgs e)
        {
            Updateuser(Convert.ToInt32(UPidtb.Text),UPusertb.Text,UPpasstb.Text,UProletb.Text);
            MessageDialog mg = new MessageDialog("User updated");
            await mg.ShowAsync();
        }

        static void Updateuser(int id,string Name, string Pass, string role)
        {

            string cs = //"Server=LAPTOP-V3EC844G;Database= forprojects; User ID = darioPROG32356f; PASSWORD=12345";
            "Server = DESKTOP-E1KF7BF; Database = forprojects; USER ID = darioPROG32356f; PASSWORD = 12345";
            string query = "Update USERS " +
                "Set NAME=@Namee, PASS=@pass, ROLES=@rl where ID=@ide"; //@ is parameter feature of ado.net

            using (SqlConnection conn = new SqlConnection(cs))
            {

                //step 2 command object
                SqlCommand cmd = new SqlCommand(query, conn);

                //step 3 we add parameter if query has where conditions or whatever
                cmd.Parameters.AddWithValue("Namee", Name);
                cmd.Parameters.AddWithValue("pass", Pass);
                cmd.Parameters.AddWithValue("rl", role);
                cmd.Parameters.AddWithValue("ide", id);

                conn.Open();

                //step 4: Execute the SQL Command by calling the 
                // sqlCommands's ExcuteReader()
                SqlDataReader reader = cmd.ExecuteReader();

            }
        }
    }
}
