﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Assigment2
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ADDUSER : Page
    {
        public ADDUSER()
        {
            this.InitializeComponent();
        }

        private async void auserbtn_Click(object sender, RoutedEventArgs e)
        {


            Insertuser(ausertb.Text, apasstb.Text, aroletb.Text);
            MessageDialog mg = new MessageDialog("User Added");
            await mg.ShowAsync();

        }

        private void home_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));

        }
        static void Insertuser(string Firstname, string Lastname, string role)
        {

            string cs = //"Server=LAPTOP-V3EC844G;Database= forprojects; User ID = darioPROG32356f; PASSWORD=12345";
            "Server = DESKTOP-E1KF7BF; Database = forprojects; USER ID = darioPROG32356f; PASSWORD = 12345";
            string query = "Insert into USERS(NAME, PASS, ROLES) " +
                "values(@FirstNamee,@LastNamee,@LastNamee1)"; //@ is parameter feature of ado.net

            using (SqlConnection conn = new SqlConnection(cs))
            {

                //step 2 command object
                SqlCommand cmd = new SqlCommand(query, conn);

                //step 3 we add parameter if query has where conditions or whatever
                cmd.Parameters.AddWithValue("FirstNamee", Firstname);
                cmd.Parameters.AddWithValue("LastNamee", Lastname);
                cmd.Parameters.AddWithValue("LastNamee1", role);

                conn.Open();

                //step 4: Execute the SQL Command by calling the 
                // sqlCommands's ExcuteReader()
                SqlDataReader reader = cmd.ExecuteReader();

            }
        }

    }
}
