﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Assigment2
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class LoginUser : Page
    {
       public static string typeuser = "GUEST";
        public LoginUser()
        {
            this.InitializeComponent();
        }

        private void loginbtn_Click(object sender, RoutedEventArgs e)
        {
            lusers(lusertb.Text, lpass.Text);
            this.Frame.Navigate(typeof(MainPage));

        }

         async void lusers(string name,string pass)
        {
            try
            {
                // using(string cs = GetConnectionString("NorthwindLocalDB")){} you don't have to close as it will automatically
                string cs = //"Server=LAPTOP-V3EC844G;Database= forprojects; User ID = darioPROG32356f; PASSWORD=12345";
                    "Server = DESKTOP-E1KF7BF; Database = forprojects; USER ID = darioPROG32356f; PASSWORD = 12345";
                //step 1 create connections
                SqlConnection conn = new SqlConnection(cs);
                string query = "Select ID, NAME, PASS, " + "ROLES from USERS where NAME=@NAME and PASS=@PASS";

                //step 2 command object
                SqlCommand cmd = new SqlCommand(query, conn);

                //step 3
                conn.Open();
                cmd.Parameters.AddWithValue("NAME", name);
                cmd.Parameters.AddWithValue("PASS", pass);

                //step 4: Execute the SQL Command by calling the 
                // sqlCommands's ExcuteReader()
                SqlDataReader reader = cmd.ExecuteReader();

                //the object returned (rader) can be used to 
                //iterate through the records returned

                while (reader.Read())
                {
                    int id = (int)reader["ID"];
                    string firstname = (string)reader["NAME"];
                    string lastNmae = (string)reader["PASS"];
                    string lastNmEae = (string)reader["ROLES"];


                    //step 5 display
                    typeuser = lastNmEae;
                    MessageDialog mg = new MessageDialog(lastNmEae);
                    await mg.ShowAsync();
                }


                //step 5 display



                //step 6
                conn.Close();
            }

            catch
            {
                MessageDialog mg = new MessageDialog("WRONG CREDENTIALS TRY AGAIN");
                await mg.ShowAsync();

            }
            
           
        }

    }
}
