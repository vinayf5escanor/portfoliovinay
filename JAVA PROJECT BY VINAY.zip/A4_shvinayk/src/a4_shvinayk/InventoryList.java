/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a4_shvinayk;

import java.util.ArrayList;

/**
 *
 * @author VINAY
 */
public class InventoryList {
    
    ArrayList <Inventory> invList=new ArrayList();
    
    public InventoryList(){
        
    }
    
    public void add(Inventory inventory){
        invList.add(inventory);
    }
    
    public Inventory get(int index){
        
        return invList.get(index);
            
    }
    public int length(){
        return invList.size();
    }
    
}
