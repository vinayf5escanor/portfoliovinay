package a4_shvinayk;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author VINAY
 */
public class Tester extends Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      Application.launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
      Parent root = FXMLLoader.load(getClass().getResource("newFXML.fxml"));
       Scene scene=new Scene(root);
       stage.setScene(scene);
       stage.setTitle("Assignment4");
       stage.show();
    }
    
}