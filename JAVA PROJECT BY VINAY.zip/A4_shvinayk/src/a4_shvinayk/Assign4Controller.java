/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a4_shvinayk;

import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.shape.Shape;

/**
 * FXML Controller class
 *
 * @author VINAY
 */
public class Assign4Controller implements Initializable {

    /**
     * Initializes the controller class.
     */
    InventoryList list = new InventoryList();

    @FXML
    Label lblL1;
    @FXML
    Label lblL2;
    @FXML
    Label lblL3;
    @FXML
    Label lblL4;
    @FXML
    Label lblL5;
    @FXML
    Label lblout;

    @FXML
    TextField txtValue1;
    @FXML
    TextField txtValue2;
    @FXML
    TextField txtValue3;
    @FXML
    TextField txtValue4;
    @FXML
    TextField txtValue5;

    @FXML
    ListView lstInven;

    @FXML
    Button btnadd, btnsave, btnorder, btnexit;

    int i = 0;
/**
 * this method also provide data validation
 * @param e 
 */
    public void save(ActionEvent e) {
        try {
            if(!Character.isAlphabetic(txtValue1.getText().charAt(0)) || !Character.isAlphabetic(txtValue1.getText().charAt(1)) || !Character.isAlphabetic(txtValue1.getText().charAt(2)) || !Character.isDigit(txtValue1.getText().charAt(4)) || !Character.isDigit(txtValue1.getText().charAt(5))
                    || !Character.isDigit(txtValue1.getText().charAt(6)) || !Character.isDigit(txtValue1.getText().charAt(7)) || txtValue1.getText().charAt(3) != '-' || txtValue1.getText().length()!=8) {
                Alert a1 = new Alert(Alert.AlertType.ERROR);
                a1.setTitle("Error");
                a1.setHeaderText("INVALID ENTRY");
                a1.setContentText("The ID should be of type 'abc-1234' ");
                a1.show();

            } else if (txtValue2.getText().isBlank()) {

                Alert a1 = new Alert(Alert.AlertType.ERROR);
                a1.setTitle("Error");
                a1.setHeaderText("INVALID ENTRY");
                a1.setContentText("Name can not be left empty!");
                a1.show();

            } else if (Integer.parseInt(txtValue3.getText()) < 0) {

                Alert a1 = new Alert(Alert.AlertType.ERROR);
                a1.setTitle("Error");
                a1.setHeaderText("INVALID ENTRY");
                a1.setContentText("QOH should be equal or greater than zero!");
                a1.show();

            } else if (Integer.parseInt(txtValue4.getText()) <= 0) {

                Alert a1 = new Alert(Alert.AlertType.ERROR);
                a1.setTitle("Error");
                a1.setHeaderText("INVALID ENTRY");
                a1.setContentText("ROP should be greater than zero!");
                a1.show();

            } else if (Integer.parseInt(txtValue5.getText()) <= 0) {

                Alert a1 = new Alert(Alert.AlertType.ERROR);
                a1.setTitle("Error");
                a1.setHeaderText("INVALID ENTRY");
                a1.setContentText("Price should be greater than zero!");
                a1.show();
            } else {
                list.add(new Inventory(txtValue1.getText(), txtValue2.getText(), Integer.parseInt(txtValue3.getText()), Integer.parseInt(txtValue4.getText()), Double.parseDouble(txtValue5.getText())));
            }

           

        } catch (Exception r) {
            Alert a1 = new Alert(Alert.AlertType.ERROR);
            a1.setTitle("Error");
            a1.setHeaderText("INVALID ENTRY");
            a1.setContentText("More than one value is wrong please Try Again!");
            a1.show();

        }
         btnsave.setDisable(true);
            btnadd.setDisable(false);
            btnorder.setDisable(false);
            
            txtValue1.clear();
            txtValue2.clear();
            txtValue3.clear();
            txtValue4.clear();
            txtValue5.clear();
    }
    
    /**
     * this is the method which will order stuff and store in listview
     * @param e 
     */
    public void order(ActionEvent e) {
        try{
     
        if (list.get(i).getQoh() < list.get(i).getRop()) {
            lstInven.getItems().add(list.get(i));
            lblout.setText("");
        }
        else
        {
            lblout.setText("Nothing to order");
        }
        }
        catch(Exception w){
            lblout.setText("Please add values to list to order");
        }
        txtValue1.clear();
        txtValue2.clear();
        txtValue3.clear();
        txtValue4.clear();
        txtValue5.clear();
        i++;
    }
/**
 * clear methods
 * @param e 
 */
    public void clear(ActionEvent e) {

        txtValue1.clear();
        txtValue2.clear();
        txtValue3.clear();
        txtValue4.clear();
        txtValue5.clear();
        btnadd.setDisable(true);
        btnorder.setDisable(true);
        btnsave.setDisable(false);

    }
/**
 * exit method
 * @param e 
 */
    public void exit(ActionEvent e) 
    {
        Alert a=new Alert(Alert.AlertType.CONFIRMATION);
        a.setTitle("Exit");
        a.setHeaderText("Please Confirm");
        a.setContentText("You want to exit program?");
        Optional <ButtonType> selection = a.showAndWait();
        if (selection.get() == ButtonType.OK){
            System.exit(0);
        } 
        else {
            //nothing
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        lblL1.setText(Field.ITEM_ID.get());
        lblL2.setText(Field.ITEM_NAME.get());
        lblL3.setText(Field.QOH.get());
        lblL4.setText(Field.ROP.get());
        lblL5.setText(Field.PRICE.get());
        btnsave.setDisable(true);

    }
}
