/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a4_shvinayk;

/**
 *
 * @author VINAY
 */
public enum Field {
    
    ITEM_ID("Inventory ID"),
    ITEM_NAME("Item Name"),
    QOH	("Qty. On Hand"),
    ROP("Re-Order Point"),
    PRICE("Unit Price");
    
    private String caption;
    
    private Field(String caption){
    this.caption=caption;
}
   
    public String get(){         //getter for name
    return caption;
}
    
    
}
