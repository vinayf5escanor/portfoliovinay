/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a5_shvinayk;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import prog24178.labs.objects.CookieInventoryItem;
import prog24178.labs.objects.Cookies;

/**
 *
 * @author VINAY
 */
public class CookieInventoryFile extends ArrayList<CookieInventoryItem> {

    public CookieInventoryFile() {

    }

    public CookieInventoryFile(File file) throws FileNotFoundException {
        this.loadFromFile(file);
    }
/**
 * method accepts a cookie flavour ID number and searches the CookieInventoryFile elements for a CookieInventoryItem with the same ID. If an item is found, that CookieInventoryItem is returned. If there is no item with that flavour ID, a null object (null) is returned.
 * @param flavID
 * @return
 * @throws FileNotFoundException 
 */
    public CookieInventoryItem find(int flavID) throws FileNotFoundException {
        
     int index=-1;
      for (CookieInventoryItem co : this) 
       {
      if (co.cookie.getId()==flavID)
         {
           index = this.indexOf(co);
           return this.get(index);
         }
       }
          
        return null;
        
    }
/**
 * method accepts a File object. The method must read all the records from the file and construct a CookieInventoryItem object for each record. Each CookieInventoryItem object is added to the ArrayList inside the CookieInventoryFile.
 * @param file
 * @throws FileNotFoundException 
 */
    public void loadFromFile(File file) throws FileNotFoundException {

   file = new File("Cookies.txt");
        if (file.exists()) {
            Scanner sc = new Scanner(file);
            while (sc.hasNextLine()) {
                String record = sc.nextLine();
                String[] field = record.split("\\|");
                this.add(new CookieInventoryItem(Integer.parseInt(field[0]), Integer.parseInt(field[1])));
            }

            sc.close();
        } else {
            System.out.println("error");
        }

    }
/**
 *  method accepts a File object. The method iterates through all of the CookieInventoryItem objects in the ArrayList and deconstructs them into a delimited string that can be written to the file. Use the toFileString() method in the CookieInventoryItem class!
 * @param file
 * @throws FileNotFoundException
 * @throws IOException 
 */
    public void writeToFile(File file) throws FileNotFoundException, IOException {
           this.loadFromFile(file);
            for (int i=0;i<this.size();i++) {
                this.get(i).toFileString();
            }

        }
}
    

