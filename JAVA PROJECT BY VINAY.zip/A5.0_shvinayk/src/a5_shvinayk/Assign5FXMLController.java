/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a5_shvinayk;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import prog24178.labs.objects.Cookies;
import static prog24178.labs.objects.Cookies.*;

/**
 * FXML Controller class
 *
 * @author VINAY
 */
public class Assign5FXMLController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private ComboBox<Cookies> ddlCookie;
    @FXML
    Button btnadd, btnsave;
    @FXML
    TextField txtSold, txtBaked;

    File file = new File("Cookies.txt");
    CookieInventoryFile cif = new CookieInventoryFile();
/**
 * this exits the system
 * @param e 
 */
    public void exit(ActionEvent e) {
        Alert a = new Alert(Alert.AlertType.CONFIRMATION);
        a.setTitle("Exit");
        a.setHeaderText("Please Confirm");
        a.setContentText("You want to exit program?");
        Optional<ButtonType> selection = a.showAndWait();
        if (selection.get() == ButtonType.OK) {
            System.exit(0);
        } else {
            //nothing
        }
    }
/**
 * add inventory to the stock
 * @param s
 * @throws IOException 
 */
    public void add(ActionEvent s) throws IOException {
        cif.loadFromFile(file);
        if (txtBaked.getText().isEmpty()) {
            Alert a1 = new Alert(Alert.AlertType.ERROR);
            a1.setTitle("Error");
            a1.setHeaderText("INVALID ENTRY");
            a1.setContentText("Please enter the number of cookies added");
            a1.show();
        } else {
            file = new File("Cookies.txt");
            FileWriter fw = new FileWriter(file, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter fileOut = new PrintWriter(bw);
            fileOut.println(ddlCookie.getValue().getId() + "|" + txtBaked.getText());
            fileOut.close();
            Alert a1 = new Alert(Alert.AlertType.INFORMATION);
            a1.setTitle("Success");
            a1.setHeaderText("Added");
            a1.setContentText("Successfully added");
            a1.show();
        }
    }
/**
 * sells inventory from the stocks
 * @param a
 * @throws IOException 
 */
    public void Sold(ActionEvent a) throws IOException {
        cif.loadFromFile(file);
        if (txtSold.getText().isEmpty() || Integer.parseInt(txtSold.getText()) <= 0) {
            Alert a1 = new Alert(Alert.AlertType.ERROR);
            a1.setTitle("Error");
            a1.setHeaderText("INVALID ENTRY");
            a1.setContentText("Please enter the number of cookies added");
            a1.show();
        } else {
            try {
                int b = ddlCookie.getValue().getId();
                if (cif.find(b) != null && cif.get(b).getQuantity() > Integer.parseInt(txtSold.getText())) {
                    cif.get(b).setQuantity(cif.get(b).getQuantity() - Integer.parseInt(txtSold.getText()));
                    Alert a1 = new Alert(Alert.AlertType.INFORMATION);
                    a1.setTitle("Sold");
                    a1.setHeaderText("Sucess");
                    a1.setContentText("Sold succesfully");
                    a1.show();
                } else {
                    Alert a1 = new Alert(Alert.AlertType.ERROR);
                    a1.setTitle("Error");
                    a1.setHeaderText("Not enough");
                    a1.setContentText("Not enough cookies");
                    a1.show();
                }
            } catch (Exception r) {
                Alert a1 = new Alert(Alert.AlertType.ERROR);
                a1.setTitle("Error Occured");
                a1.setHeaderText("Try Again");

                a1.show();
            }

        }
    }
/**
 * intialize evrything
 * @param url
 * @param rb 
 */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        ObservableList<Cookies> cookieList = FXCollections.observableArrayList();

        cookieList.addAll(APRICOT_RUGALACH, BUTTER_ALMOND, CARDAMOM_CHOCOLATE, CHOCOLATE_CHIP, CINNAMON_SNAP, DOUBLE_CHOCOLATE, GINGER_SNAP, MACADAMIA, NAN_KHATAI, OATMEAL, OATMEAL_DATE, OATMEAL_RAISIN, PEANUT_BUTTER, PEANUT_CHOCOLATE, PISTACHIO_QURABIYA, RASPBERRY_ROSENMUNNAR, SHORTBREAD, STRAWBERRY_CREAM, TOFFEE_PECAN);
        ddlCookie.setItems(cookieList);
        ddlCookie.getSelectionModel().select(0);

    }

}
