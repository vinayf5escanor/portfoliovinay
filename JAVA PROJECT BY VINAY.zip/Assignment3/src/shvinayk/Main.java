/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shvinayk;
import java.util.*;
/**
 *
 * @author VINAY
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner v=new Scanner(System.in);
        ShipmentList store=new ShipmentList();
        Destination code=Destination.ON;
        double val=0;//intialested value
        boolean isValid=true;//intialested value
        boolean rep =true;//intialested value
        String prov="ON"; //intialested value
        
        do
        {
          do
          {
            try
            {
               System.out.print("Enter Destination Provience code: ");
               prov=v.nextLine();
               code=Destination.valueOf(prov.toUpperCase());              //FOR PR0VIENCE INPUT
               isValid=true;                                              
            }
            catch (IllegalArgumentException e) 
            {
            System.out.println("Enter valid provience code");
            isValid=false;
            }
          }while(isValid==false);

        do
        {
           try
           {
             System.out.print("Enter Total Value of Shipment: ");
             val=v.nextDouble()+code.getCost();                              //value input
             isValid=true;
           }
           catch (Exception w) 
           {
             System.out.println("Enter valid value");
             isValid=false;
             v.next();}
           }while(isValid==false);
        
         if(store.findShipment(code)==-1)
         {
            store.add(new Shipment(code,val));
         }
        else 
          store.get(store.findShipment(code)).addShipValue(val);
           
            System.out.println("ADD ANOTHER Y/N: ");
            String vin = v.next();
        
            if(!"Y".equals(vin)) 
            {
                rep=false; 
            }
             v.nextLine();//buffer flusher
            
        
        }while(rep);           

        
        
        System.out.println("This weeks shipments: ");
        System.out.println(store);
        System.out.println();
        System.out.println("Most valuable payment: ");
        
       double max=store.get(0).getShipValue();
        for(int i=0;i<store.length();i++)
        { 
            if(store.get(0).getShipValue()<store.get(i).getShipValue())
            {
             max=store.get(i).getShipValue(); 
            }
            
        }
        System.out.println(max);
        
 
    } //end of main method
    } //end of class
    

