/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shvinayk;

import java.util.ArrayList; // arraylist package imports here

/**
 *@version 2.0
 * @author VINAY
 */
public class ShipmentList {
    
   
    private ArrayList<Shipment> shipmentList= new ArrayList(); // this is a private list which stores the value
    
    
    public ShipmentList(){}   //default constuctor
    
    /**
     * This is the method which take up a int value and get the shipment stored there
     * @param index
     * @return index of the element
     */
    public Shipment get(int index)  
    {
        return shipmentList.get(index);
    }
    
    /**
     * This method add if their is no same shipment in the list
     * @param shipment 
     */
    public void add(Shipment shipment)
    {
         if(this.findShipment(shipment.destination)==-1)
           shipmentList.add(shipment);          
    }
    
    /**
     * this is the complex method which find the shipment in the list according to the destination enum entered
     * @param destination
     * @return 
     */
    public int findShipment(Destination destination)
    {
              int index=-1;
      for (Shipment shipExist : shipmentList) 
       {
      if (shipExist.destination.getName().equals(destination.getName())) 
         {
           index = shipmentList.indexOf(shipExist);
         }
       }
          return index;
    }

/**
 * 
 * @return int value number of element stored in the list
 */
     public int length(){
         return shipmentList.size();
     }     
    
     /**
      * modified to string method
      * @return formatted representation of shipment maid
      */
     @Override
     public String toString(){
        
         for (int i = 0; i < shipmentList.size(); i++) {
             System.out.println(this.get(i).toString());
             
         }
         return "end of list";
             
             
     }
}//end of class
    


