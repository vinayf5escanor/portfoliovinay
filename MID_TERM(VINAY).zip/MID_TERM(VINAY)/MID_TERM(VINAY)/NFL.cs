﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MID_TERM_VINAY_
{
    class NFL
    {
   //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       //variable all encapsulated
        private String Team1, Team2;
        private int TeamTotal1, TeamTotal2;
        private int td1, td2;
        private int tb1, tb2;
        private int kick1, conv1, kick2, conv2;
        private int tdc1, tdc2;
   //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //the game starts here
        public void StartGame(int quat)
        {
            Random rnd = new Random();  //this guy is the key to cracking this mid term
            int score1,score2;
           
            for (int i=0;i<quat;i++)
            {
                int prob= rnd.Next(-1, 2);
                td1 = rnd.Next(0, 4);   //touchdown generator
                td2 = rnd.Next(0, 4);
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
           // extra point are handled here
                if (td1>0)
                {
                    tdc1 = tdc1+td1;
                    if (prob < 0)           
                    {
                        kick1 = kick1 + 1;
                        td1 =td1 + 1;
                    }
                  else if (prob > 0)
                    {
                        conv1 = conv1 + 2;
                        td1 = td1 + 2;
                    }
                }

                if (td2 > 0)
                {
                    tdc2 = tdc2 + td2;
                    if (prob < 0)
                    {
                        kick2 = kick2 + 1;
                        td2 = td2 + 1;
                    }
                   else if (prob > 0)
                    {
                        conv2 = conv2 + 1;
                        td2 = td2 + 2;
                    }
                }
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
         // Finalazing score or closing
                score1 = td1 * 6;
                score2 = td2 * 6;
                Team1 = Team1+score1 + "\t";
                Team2 = Team2+score2 + "\t";
                TeamTotal1 = TeamTotal1 + score1;
                TeamTotal2 = TeamTotal2 + score2;
               
            }
   //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        // if point are equal then to determine a winner over time is played here
            if (TeamTotal1 == TeamTotal2)
            {
                tb1 = rnd.Next(0, 30);
                tb2 = rnd.Next(0, 30);
                TeamTotal1 = TeamTotal1 + tb1;
                TeamTotal1 = TeamTotal1 + tb2;
            }
        }
  //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       // getter and setter for all varibales 
        public String getTeam1()
        {
            return Team1;
        }

        public String getTeam2()
        {
            return Team2;
        }

        public String getTouchdown1()
        {
            return td1+"";
        }

        public String getTouchdown2()
        {
            return td2+"";
        }

        public String getot1()
        {
            return tb1 + "\t";
        }

        public String getot2()
        {
            return tb2 + "\t";
        }

        public String getkick1()
        {
            return kick1 + "\t";
        }

        public String getconv1()
        {
            return conv1 + "\t";
        }

        public String getkick2()
        {
            return kick2 + "\t";
        }

        public String getconv2()
        {
            return conv2 + "\t";
        }

        public String tdcteam1()
        {
            return tdc1+"\t";
        }

        public String tdcteam2()
        {
            return tdc2 + "\t";
        }

        public String getTeamTotal1()
        {
            if(TeamTotal1>TeamTotal2)
            {
                return TeamTotal1 + " (win)";
            }
            return TeamTotal1+"";
        }

        public String getTeamTotal2()
        {
            if (TeamTotal1 < TeamTotal2)
            {
                return TeamTotal2 + " (win)";
            }
            return TeamTotal2+"";
        }

        public int getTeamTotalK()
        {  
            return TeamTotal1;
        }

        public int getTeamTotalP()
        {
            return TeamTotal2;
        }
   //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    }
}
