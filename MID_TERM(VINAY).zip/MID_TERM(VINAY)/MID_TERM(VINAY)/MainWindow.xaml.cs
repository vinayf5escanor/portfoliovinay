﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MID_TERM_VINAY_
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int quad = Convert.ToInt32(Qtext.Text); //getting value from textbox
            string quater="";

            for(int i=1;i<=quad;i++)
            {
                quater = quater + i+"\t"; //formating header lable
            }
            quat.Content = quater+"OT\t"+"T"; //updating my lables
  //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
           // statring game anf updating labels to show score
            NFL nfl = new NFL();
            nfl.StartGame(quad);
            score1.Content = nfl.getTeam1() + nfl.getot1() + nfl.getTeamTotal1();
            score2.Content = nfl.getTeam2() + nfl.getot2() + nfl.getTeamTotal2();
            ttl1.Content = nfl.getTeamTotal1();
            ttl2.Content = nfl.getTeamTotal2();
  //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
           // formating the data as string and storing it in readable format in stats
            String myformatStats ="\nTotal Touchdown KC : \t"+nfl.tdcteam1()+ "\nTotal Touchdown Bay : \t" + nfl.tdcteam2()
                 + "\nSuccessful kick KC : \t" + nfl.getkick1() + "\nSuccessful kick Bay : \t" + nfl.getkick2()
                  + "\nSuccessful Conversion KC : \t" + nfl.getconv1() + "\nSuccessful Conversion Bay : \t" + nfl.getconv2()
                  + "\nUnSuccessful extra point KC : \t" + (Convert.ToInt32(nfl.getTouchdown1())+3-(Convert.ToInt32(nfl.getconv1())+1+ Convert.ToInt32(nfl.getkick1())))
                  +"\nUnSuccessful extra point Bay : \t" + (Convert.ToInt32(nfl.getTouchdown2())+3 - (Convert.ToInt32(nfl.getconv2())+ 1 + Convert.ToInt32(nfl.getkick2())));
            System.IO.File.WriteAllText(@"C:\Users\VINAY\source\repos\MID_TERM(VINAY)\MID_TERM(VINAY)\stats.txt", myformatStats);
   //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // formating the data as string and storing it in readable format in score
            String myformatScore ="\t\t"+quater + "OT\t" + "T\nTeam KC\t\t" + nfl.getTeam1() + nfl.getot1() + nfl.getTeamTotal1() + "\nTeam Bay\t" + nfl.getTeam2() + nfl.getot2() + nfl.getTeamTotal2();
            System.IO.File.WriteAllText(@"C:\Users\VINAY\source\repos\MID_TERM(VINAY)\MID_TERM(VINAY)\score.txt", myformatScore);
   //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // formating the data as string and storing it in readable format in stats2
            int total1 = nfl.getTeamTotalK()/quad;
            int total2 = nfl.getTeamTotalP() /quad;
            String myformatStats2 = "average scored by the Patriots\t" + total1
                                   + "\naverage scored by the Buccaneers\t" + total2;
            System.IO.File.WriteAllText(@"C:\Users\VINAY\source\repos\MID_TERM(VINAY)\MID_TERM(VINAY)\stats2.txt", myformatStats2);
   //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // formating the data as string and storing it in readable format in stats multiplerun
            String myformatScoreMultiple = "\n\t\t" + quater + "OT\t" + "T\n"+"Team KC\t\t" + nfl.getTeam1() + nfl.getot1() + nfl.getTeamTotal1() + "\nTeam Bay\t" + nfl.getTeam2() + nfl.getot2() + nfl.getTeamTotal2()+"\n";
            System.IO.File.AppendAllText(@"C:\Users\VINAY\source\repos\MID_TERM(VINAY)\MID_TERM(VINAY)\multiplerun.txt", myformatScoreMultiple);
   //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // formating the data as string and storing it in readable format in infinite
            if (quad > 4)
            {
                String myformatScoreInfinite = "\n\t\t" + quater + "OT\t" + "T\nTeam KC\t\t" + nfl.getTeam1() + nfl.getot1() + nfl.getTeamTotal1() + "\nTeam Bay\t" + nfl.getTeam2() + nfl.getot2() + nfl.getTeamTotal2()+"\n";
                System.IO.File.WriteAllText(@"C:\Users\VINAY\source\repos\MID_TERM(VINAY)\MID_TERM(VINAY)\infinite.txt", myformatScoreInfinite);
            }
   //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


        }
    }
}
